import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import API from '../client';

export default function Recipe() {
  const { id } = useParams();
  const [recipe, setRecipe] = useState(null);
  const [comment, setComment] = useState('');

  useEffect(() => {
    fetchRecipe();
  }, [id]);

  const fetchRecipe = async () => {
    try {
      const { data } = await API.get(`/recipes/${id}`);
      setRecipe(data);
    } catch (err) {
      console.error(err);
    }
  };

  const handleLike = async () => {
    try {
      await API.post(`/recipes/${id}/like`);
      fetchRecipe();
    } catch (err) {
      alert('Login required');
    }
  };

  const handleComment = async (e) => {
    e.preventDefault();
    try {
      await API.post(`/recipes/${id}/comments`, { text: comment });
      setComment('');
      fetchRecipe();
    } catch (err) {
      alert('Login required');
    }
  };

  if (!recipe) return <div>Loading...</div>;

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-4">{recipe.title}</h1>
      {recipe.image && <img src={`http://localhost:5000/${recipe.image}`} alt={recipe.title} className="w-full h-64 object-cover rounded mb-4" />}
      <p className="text-gray-600 mb-4">{recipe.description}</p>
      <p className="text-sm text-gray-500 mb-4">By {recipe.author.name}</p>
      <button onClick={handleLike} className="text-red-500 mb-4">❤️ {recipe.likes.length} Likes</button>
      <div className="mb-6">
        <h2 className="text-2xl font-semibold mb-2">Ingredients</h2>
        <ul className="list-disc list-inside">
          {recipe.ingredients.map((ing, i) => <li key={i}>{ing}</li>)}
        </ul>
      </div>
      <div className="mb-6">
        <h2 className="text-2xl font-semibold mb-2">Steps</h2>
        <ol className="list-decimal list-inside">
          {recipe.steps.map((step, i) => <li key={i}>{step}</li>)}
        </ol>
      </div>
      <div>
        <h2 className="text-2xl font-semibold mb-2">Comments</h2>
        <form onSubmit={handleComment} className="mb-4">
          <textarea
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="Add a comment..."
            className="w-full p-2 border rounded"
            required
          />
          <button type="submit" className="mt-2 bg-blue-500 text-white p-2 rounded">Comment</button>
        </form>
        {recipe.comments.map((c, i) => (
          <div key={i} className="border-b py-2">
            <strong>{c.user.name}:</strong> {c.text}
          </div>
        ))}
      </div>
    </div>
  );
}
