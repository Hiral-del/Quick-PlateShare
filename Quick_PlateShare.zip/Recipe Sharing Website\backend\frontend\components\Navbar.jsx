import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

export default function Navbar() {
  const navigate = useNavigate();
  const token = localStorage.getItem('token');

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/auth');
  };

  return (
    <nav className="bg-blue-600 text-white p-4">
      <div className="container mx-auto flex justify-between items-center">
        <Link to="/" className="text-xl font-bold">Quick PlateShare</Link>
        <div className="space-x-4">
          <Link to="/" className="hover:underline">Home</Link>
          {token ? (
            <>
              <Link to="/create" className="hover:underline">Create Recipe</Link>
              <button onClick={handleLogout} className="hover:underline">Logout</button>
            </>
          ) : (
            <Link to="/auth" className="hover:underline">Login</Link>
          )}
        </div>
      </div>
    </nav>
  );
}
