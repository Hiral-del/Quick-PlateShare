# TODO: Complete Quick PlateShare Recipe Website

## Backend Enhancements
- [ ] Create backend/models/Recipe.js with likes and comments fields
- [ ] Update backend/recipe.js to include like and comment routes
- [ ] Ensure all models and routes are properly connected

## Frontend Pages (3 Pages)
- [ ] Update frontend/pages/Auth.jsx for login/register
- [ ] Update frontend/pages/Home.jsx as recipes list with likes/comments
- [ ] Update frontend/pages/CreateRecipe.jsx for creating recipes
- [ ] Create frontend/components/Navbar.jsx
- [ ] Add styles and ensure responsive design

## Deployment Prep
- [ ] Add Dockerfile for containerization
- [ ] Create .env.example
- [ ] Update README.md with setup instructions
- [ ] Initialize Git repository
- [ ] Create GitHub repository and push code
- [ ] Create zip file of the project

## Testing and Finalization
- [ ] Install dependencies and test locally
- [ ] Verify auth, recipe CRUD, likes, comments
- [ ] Ensure ready for deployment
