import React from 'react'
import { Routes, Route } from 'react-router-dom'
import Home from './pages/Home'
import Recipe from './pages/Recipe'
import CreateRecipe from './pages/CreateRecipe'
import Auth from './pages/Auth'
import Navbar from './components/Navbar'


export default function App(){
return (
<div className="min-h-screen bg-gray-50">
<Navbar />
<main className="container mx-auto p-4">
<Routes>
<Route path="/" element={<Home/>} />
<Route path="/recipes/:id" element={<Recipe/>} />
<Route path="/create" element={<CreateRecipe/>} />
<Route path="/auth" element={<Auth/>} />
</Routes>
</main>
</div>
)
}