const express = require('express');
const router = express.Router();
const Recipe = require('../models/Recipe');
const auth = require('./auth');
const upload = require('./upload');


// Create recipe
router.post('/', auth, upload.single('image'), async (req, res) => {
  const { title, description, ingredients, steps, category } = req.body;
  const image = req.file ? req.file.filename : undefined;
  const recipe = await Recipe.create({ title, description, ingredients: JSON.parse(ingredients || '[]'), steps: JSON.parse(steps || '[]'), image, author: req.user.id, category });
  res.json(recipe);
});


// Get list (with pagination & search)
router.get('/', async (req, res) => {
  const { page = 1, limit = 10, q } = req.query;
  const filter = q ? { $text: { $search: q } } : {};
  const recipes = await Recipe.find(filter).populate('author', 'name').skip((page - 1) * limit).limit(parseInt(limit)).sort({ createdAt: -1 });
  res.json(recipes);
});


// Get single
router.get('/:id', async (req, res) => {
  const recipe = await Recipe.findById(req.params.id).populate('author', 'name').populate('comments.user', 'name');
  res.json(recipe);
});


// Update
router.put('/:id', auth, upload.single('image'), async (req, res) => {
  const updates = req.body;
  if (req.file) updates.image = req.file.filename;
  const recipe = await Recipe.findByIdAndUpdate(req.params.id, updates, { new: true });
  res.json(recipe);
});


// Delete
router.delete('/:id', auth, async (req, res) => {
  await Recipe.findByIdAndDelete(req.params.id);
  res.json({ success: true });
});


// Like recipe
router.post('/:id/like', auth, async (req, res) => {
  const recipe = await Recipe.findById(req.params.id);
  if (!recipe.likes.includes(req.user.id)) {
    recipe.likes.push(req.user.id);
    await recipe.save();
  }
  res.json({ likes: recipe.likes.length });
});


// Unlike recipe
router.delete('/:id/like', auth, async (req, res) => {
  const recipe = await Recipe.findById(req.params.id);
  recipe.likes = recipe.likes.filter(id => id.toString() !== req.user.id);
  await recipe.save();
  res.json({ likes: recipe.likes.length });
});


// Add comment
router.post('/:id/comments', auth, async (req, res) => {
  const { text } = req.body;
  const recipe = await Recipe.findById(req.params.id);
  recipe.comments.push({ user: req.user.id, text });
  await recipe.save();
  await recipe.populate('comments.user', 'name');
  res.json(recipe.comments);
});


module.exports = router;
