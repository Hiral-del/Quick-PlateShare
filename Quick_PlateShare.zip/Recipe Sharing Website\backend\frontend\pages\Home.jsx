import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import API from '../client';

export default function Home() {
  const [recipes, setRecipes] = useState([]);
  const [search, setSearch] = useState('');

  useEffect(() => {
    fetchRecipes();
  }, [search]);

  const fetchRecipes = async () => {
    try {
      const { data } = await API.get(`/recipes?q=${search}`);
      setRecipes(data);
    } catch (err) {
      console.error(err);
    }
  };

  const handleLike = async (id) => {
    try {
      await API.post(`/recipes/${id}/like`);
      fetchRecipes();
    } catch (err) {
      alert('Login required');
    }
  };

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Quick PlateShare</h1>
      <input
        type="text"
        placeholder="Search recipes..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="w-full p-2 mb-6 border rounded"
      />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {recipes.map((recipe) => (
          <div key={recipe._id} className="bg-white p-4 rounded-lg shadow-md">
            {recipe.image && <img src={`http://localhost:5000/${recipe.image}`} alt={recipe.title} className="w-full h-48 object-cover rounded mb-4" />}
            <h2 className="text-xl font-semibold mb-2">{recipe.title}</h2>
            <p className="text-gray-600 mb-2">{recipe.description}</p>
            <p className="text-sm text-gray-500">By {recipe.author.name}</p>
            <div className="flex justify-between items-center mt-4">
              <button onClick={() => handleLike(recipe._id)} className="text-red-500">
                ❤️ {recipe.likes.length}
              </button>
              <Link to={`/recipes/${recipe._id}`} className="text-blue-500">View</Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
