require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');
const connectDB = require('./db');

const app = express();
app.use(helmet());
app.use(cors({ origin: process.env.CLIENT_URL || '*' }));
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, process.env.UPLOAD_DIR || 'uploads')));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 200 }));

// Connect DB
connectDB(process.env.MONGO_URI || 'mongodb://localhost:27017/recipeapp');

// Routes
app.use('/api/auth', require('./authroutes'));
app.use('/api/recipes', require('./recipe'));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
